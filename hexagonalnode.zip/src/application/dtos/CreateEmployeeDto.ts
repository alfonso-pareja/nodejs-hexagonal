export interface CreateEmployeeDTO {
    name: string;
    email: string;
}
