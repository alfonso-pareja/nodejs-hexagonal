export const publicRoutes = [
  { method: 'POST', path: '/api/auth/login' }
];
